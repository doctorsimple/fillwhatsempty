function apage_menu() {
    var items = {};
    items['lookitme'] = {
        title : 'Lookitme',
        page_callback : 'apage_lookitme',
        region : {
            name: 'header',
            options: {
                attributes: {
                    'data-icon': 'plus',
                    'class': 'ui-btn-right'
                }
            },
            pages : {
                value: ['lookitme'],
                mode: 'include'
            }
        }
    };
    return items;
}

function apage_lookitme() {
    var content = {};
    content['my_button'] = {
        theme: 'button',
        text: 'Hello World',
        attributes: {
            onclick: "drupalgap_alert('Hi!')"
        }
    };
    return content;
}